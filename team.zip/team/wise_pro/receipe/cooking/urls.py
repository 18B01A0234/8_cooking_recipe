from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('login1',views.login1,name='login1'),
    path('signup', views.signup, name='signup'),
    path('password',views.password,name='password'),
    path('logout',views.logout,name='logout'),
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
