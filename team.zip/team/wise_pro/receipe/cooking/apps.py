from django.apps import AppConfig


class CookingConfig(AppConfig):
    name = 'cooking'
