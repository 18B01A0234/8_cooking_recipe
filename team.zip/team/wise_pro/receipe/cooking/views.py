from django.shortcuts import render
from django.http import HttpResponse
    
def home(request):
    return render(request,"home.html")
    
def login1(request):
    return render(request,"login1.html")
    
def signup(request):
  return render(request,"signup.html")
  
def password(request):
  return render(request,"password.html")
  
def logout(request):
    return render(request,"logout.html")
 
